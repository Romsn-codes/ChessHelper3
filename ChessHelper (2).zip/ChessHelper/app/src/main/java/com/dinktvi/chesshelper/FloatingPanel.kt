package com.dinktvi.chesshelper

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Плавающее окно поверх всего: статус и кнопки «Начать / Пауза», «Калибровка», «Стоп». Перетаскивается за заголовок. */
class FloatingPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val onToggle: () -> Unit,
    private val onCalibrate: () -> Unit,
    private val onStop: () -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val root = LinearLayout(ctx)
    private val statusView = TextView(ctx)
    private val startBtn = Button(ctx)
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )
    private var added = false

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(10), dp(8), dp(10), dp(8))
        root.background = GradientDrawable().apply { setColor(0xEE202124.toInt()); cornerRadius = dp(14).toFloat() }

        val title = TextView(ctx).apply {
            text = "♟ Помощник  ⋮⋮ (тяни)"
            setTextColor(Color.WHITE); textSize = 13f
        }
        statusView.apply {
            text = "Открой партию и нажми «Начать»"
            setTextColor(0xFFCFD8DC.toInt()); textSize = 12f
            maxWidth = dp(230)
            setPadding(0, dp(4), 0, dp(6))
        }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(b: Button, t: String, click: () -> Unit) {
            b.text = t; b.textSize = 12f; b.isAllCaps = false
            b.minHeight = 0; b.minimumHeight = 0; b.minWidth = 0; b.minimumWidth = 0
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener { click() }
            row.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        }
        small(startBtn, "Начать") { onToggle() }
        small(Button(ctx), "Калибровка") { onCalibrate() }
        small(Button(ctx), "Стоп") { onStop() }

        root.addView(title); root.addView(statusView); root.addView(row)

        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12); lp.y = dp(120)

        var sx = 0f; var sy = 0f
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x - e.rawX; sy = lp.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + sx).toInt(); lp.y = (e.rawY + sy).toInt()
                    if (added) wm.updateViewLayout(root, lp)
                }
            }
            true
        }
    }

    fun show() { if (!added) { wm.addView(root, lp); added = true } }
    fun remove() { if (added) { try { wm.removeView(root) } catch (_: Exception) {}; added = false } }
    fun setVisible(v: Boolean) { root.visibility = if (v) View.VISIBLE else View.INVISIBLE }
    fun setStatus(t: String) { statusView.text = t }
    fun setActive(a: Boolean) { startBtn.text = if (a) "Пауза" else "Начать" }
}
