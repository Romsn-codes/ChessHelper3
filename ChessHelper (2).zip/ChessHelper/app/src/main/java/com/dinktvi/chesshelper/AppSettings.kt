package com.dinktvi.chesshelper

import android.content.Context

/** Настройки уровня Stockfish и дебютной системы (сохраняются между запусками). */
object AppSettings {
    /** Название и значение UCI_Elo (0 = без ограничения силы). */
    val LEVELS: List<Pair<String, Int>> = listOf(
        "Новичок (~1350)" to 1350,
        "Любитель (~1600)" to 1600,
        "Клубный игрок (~1900)" to 1900,
        "Кандидат в мастера (~2200)" to 2200,
        "Мастер (~2500)" to 2500,
        "Гроссмейстер (~2800)" to 2800,
        "Максимум (без ограничений)" to 0
    )

    val STYLES = listOf("Смешанный (как считает Stockfish)", "Агрессивный", "Защитный")

    private fun p(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun levelIndex(ctx: Context) = p(ctx).getInt("level", LEVELS.size - 1).coerceIn(0, LEVELS.size - 1)
    fun setLevelIndex(ctx: Context, i: Int) = p(ctx).edit().putInt("level", i).apply()

    fun systemIndex(ctx: Context) = p(ctx).getInt("system", 0).coerceIn(0, Openings.NAMES.size - 1)
    fun styleIndex(ctx: Context) = p(ctx).getInt("style", 0).coerceIn(0, STYLES.size - 1)
    fun setStyleIndex(ctx: Context, i: Int) = p(ctx).edit().putInt("style", i).apply()

    fun setSystemIndex(ctx: Context, i: Int) = p(ctx).edit().putInt("system", i).apply()
}
