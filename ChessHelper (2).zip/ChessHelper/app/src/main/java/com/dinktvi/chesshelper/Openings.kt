package com.dinktvi.chesshelper

/**
 * Дебютные системы. Список ходов задан для белых; за чёрных он зеркалится
 * (d2d4 -> d7d5 и т.д.). Ход системы рекомендуется, только если он возможен
 * и Stockfish считает его не хуже лучшего более чем на TOLERANCE_CP сотых пешки.
 */
object Openings {
    class Step(val piece: Char, val from: String, val to: String)
    class OpeningSystem(val name: String, val steps: List<Step>)

    const val TOLERANCE_CP = 80
    const val MIN_PIECES_FOR_BOOK = 24   // после ~10 ходов система уже не навязывается

    private fun s(piece: Char, from: String, to: String) = Step(piece, from, to)

    val ALL: List<OpeningSystem> = listOf(
        OpeningSystem("Без системы (только Stockfish)", emptyList()),
        OpeningSystem("Лондонская система", listOf(
            s('P', "d2", "d4"), s('N', "g1", "f3"), s('B', "c1", "f4"), s('P', "e2", "e3"),
            s('P', "c2", "c3"), s('N', "b1", "d2"), s('B', "f1", "d3"), s('K', "e1", "g1"), s('P', "h2", "h3")
        )),
        OpeningSystem("Система Колле", listOf(
            s('P', "d2", "d4"), s('N', "g1", "f3"), s('P', "e2", "e3"), s('B', "f1", "d3"),
            s('N', "b1", "d2"), s('K', "e1", "g1"), s('P', "c2", "c3"), s('P', "e3", "e4")
        )),
        OpeningSystem("Итальянская партия", listOf(
            s('P', "e2", "e4"), s('N', "g1", "f3"), s('B', "f1", "c4"), s('P', "c2", "c3"),
            s('P', "d2", "d3"), s('K', "e1", "g1"), s('N', "b1", "d2")
        )),
        OpeningSystem("Испанская партия (Рюи Лопес)", listOf(
            s('P', "e2", "e4"), s('N', "g1", "f3"), s('B', "f1", "b5"), s('K', "e1", "g1"),
            s('P', "c2", "c3"), s('P', "h2", "h3")
        )),
        OpeningSystem("Ферзевый гамбит", listOf(
            s('P', "d2", "d4"), s('P', "c2", "c4"), s('N', "b1", "c3"), s('N', "g1", "f3"),
            s('B', "c1", "g5"), s('P', "e2", "e3"), s('B', "f1", "d3"), s('K', "e1", "g1")
        )),
        OpeningSystem("Староиндийская атака", listOf(
            s('N', "g1", "f3"), s('P', "g2", "g3"), s('B', "f1", "g2"), s('K', "e1", "g1"),
            s('P', "d2", "d3"), s('N', "b1", "d2"), s('P', "e2", "e4")
        )),
        OpeningSystem("Атака Торре", listOf(
            s('P', "d2", "d4"), s('N', "g1", "f3"), s('B', "c1", "g5"), s('P', "e2", "e3"),
            s('N', "b1", "d2"), s('P', "c2", "c3"), s('B', "f1", "d3"), s('K', "e1", "g1")
        )),
        OpeningSystem("Дебют Берда", listOf(
            s('P', "f2", "f4"), s('N', "g1", "f3"), s('P', "e2", "e3"), s('B', "f1", "e2"),
            s('K', "e1", "g1"), s('P', "d2", "d3"), s('N', "b1", "c3")
        ))
    )

    const val RANDOM_NAME = "Случайная система (на каждый запуск своя)"

    val NAMES: List<String> get() = ALL.map { it.name } + RANDOM_NAME

    /** index из выпадающего списка -> система (последний пункт — случайная из настоящих систем). */
    fun byIndex(i: Int): OpeningSystem = if (i >= ALL.size) ALL.drop(1).random() else ALL[i]

    private fun mirror(sq: String) = "${sq[0]}${9 - (sq[1] - '0')}"

    /** Ход системы в формате UCI, который сейчас можно попробовать, по порядку списка. */
    fun candidates(sys: OpeningSystem, board: Array<CharArray>, white: Boolean): List<String> {
        val out = ArrayList<String>()
        for (st in sys.steps) {
            val from = if (white) st.from else mirror(st.from)
            val to = if (white) st.to else mirror(st.to)
            val piece = if (white) st.piece else st.piece.lowercaseChar()
            val (fr, fc) = Fen.squareToRC(from)
            val (tr, tc) = Fen.squareToRC(to)
            if (board[fr][fc] == piece && board[tr][tc] == ' ') out.add(from + to)
        }
        return out
    }

    fun pieceCount(board: Array<CharArray>): Int = board.sumOf { row -> row.count { it != ' ' } }
}
