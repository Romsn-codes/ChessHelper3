package com.dinktvi.chesshelper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Прозрачный слой поверх экрана: рисует стрелки лучших ходов. */
class ArrowOverlay(ctx: Context) : View(ctx) {
    class Arrow(val fromRow: Int, val fromCol: Int, val toRow: Int, val toCol: Int, val label: String)

    private var board: RectF? = null
    private var arrows: List<Arrow> = emptyList()
    private val colors = intArrayOf(0xCC2E9E3E.toInt(), 0xCCE8A317.toInt(), 0xCC2F7DE1.toInt())
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val textBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    val hasArrows: Boolean get() = arrows.isNotEmpty()

    fun setArrows(rect: RectF?, list: List<Arrow>) {
        board = rect
        arrows = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val b = board ?: return
        val cell = b.width() / 8f
        for (i in arrows.indices.reversed()) {      // лучший ход рисуется последним — сверху
            val a = arrows[i]
            val col = colors[i.coerceAtMost(2)]
            val x1 = b.left + (a.fromCol + 0.5f) * cell
            val y1 = b.top + (a.fromRow + 0.5f) * cell
            val x2 = b.left + (a.toCol + 0.5f) * cell
            val y2 = b.top + (a.toRow + 0.5f) * cell
            val ang = atan2(y2 - y1, x2 - x1)
            val head = cell * 0.42f
            val sx = x2 - cos(ang) * head * 0.8f
            val sy = y2 - sin(ang) * head * 0.8f
            line.color = col
            line.strokeWidth = cell * (if (i == 0) 0.18f else 0.12f)
            canvas.drawLine(x1, y1, sx, sy, line)
            val p = Path().apply {
                moveTo(x2, y2)
                lineTo(x2 - cos(ang - 0.45f) * head, y2 - sin(ang - 0.45f) * head)
                lineTo(x2 - cos(ang + 0.45f) * head, y2 - sin(ang + 0.45f) * head)
                close()
            }
            fill.color = col
            canvas.drawPath(p, fill)
            // оценка у начала стрелки
            text.textSize = cell * 0.26f
            textBg.color = col
            val w = text.measureText(a.label) + cell * 0.2f
            canvas.drawRoundRect(x1 - w / 2, y1 - cell * 0.2f, x1 + w / 2, y1 + cell * 0.16f, 8f, 8f, textBg)
            canvas.drawText(a.label, x1, y1 + cell * 0.1f, text)
        }
    }
}
