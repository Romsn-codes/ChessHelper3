package com.dinktvi.chesshelper

/** Доска: b[0][0] = клетка a8, b[7][7] = h1. Пусто = ' ', белые — заглавные буквы. */
object Fen {
    fun valid(b: Array<CharArray>): Boolean {
        var wk = 0; var bk = 0
        for (r in 0..7) for (c in 0..7) {
            val ch = b[r][c]
            if (ch == 'K') wk++
            if (ch == 'k') bk++
            if ((r == 0 || r == 7) && (ch == 'P' || ch == 'p')) return false
        }
        return wk == 1 && bk == 1
    }

    fun build(b: Array<CharArray>, side: Char): String {
        val sb = StringBuilder()
        for (r in 0..7) {
            var empty = 0
            for (c in 0..7) {
                val ch = b[r][c]
                if (ch == ' ') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(ch)
                }
            }
            if (empty > 0) sb.append(empty)
            if (r < 7) sb.append('/')
        }
        val cs = StringBuilder()
        if (b[7][4] == 'K' && b[7][7] == 'R') cs.append('K')
        if (b[7][4] == 'K' && b[7][0] == 'R') cs.append('Q')
        if (b[0][4] == 'k' && b[0][7] == 'r') cs.append('k')
        if (b[0][4] == 'k' && b[0][0] == 'r') cs.append('q')
        val castling = if (cs.isEmpty()) "-" else cs.toString()
        return "$sb $side $castling - 0 1"
    }

    /** "e2" -> (строка 6, столбец 4) в координатах доски (a8 = 0,0). */
    fun squareToRC(sq: String): Pair<Int, Int> = Pair(8 - (sq[1] - '0'), sq[0] - 'a')
}
