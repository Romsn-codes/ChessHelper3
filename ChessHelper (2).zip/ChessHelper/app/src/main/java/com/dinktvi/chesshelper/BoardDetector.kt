package com.dinktvi.chesshelper

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs

/** Уменьшенная копия кадра в оттенках серого — на ней ищем шахматную сетку. */
class Frame(src: Bitmap) {
    val scale: Float
    val w: Int
    val h: Int
    val lum: IntArray

    init {
        val targetW = 360
        scale = if (src.width > targetW) targetW.toFloat() / src.width else 1f
        w = (src.width * scale).toInt()
        h = (src.height * scale).toInt()
        val s = if (scale < 1f) Bitmap.createScaledBitmap(src, w, h, true) else src
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        lum = IntArray(w * h) {
            val c = px[it]
            (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        }
        if (s !== src) s.recycle()
    }
}

/** Ищет на экране квадрат 8x8 с чередующимися светлыми/тёмными клетками. */
object BoardDetector {
    private const val DIFF_MIN = 12   // соседние клетки должны отличаться яркостью
    private const val SAME_MAX = 10   // клетки через одну — быть похожими
    private const val ACCEPT = 0.88

    private fun score(f: Frame, x0: Int, y0: Int, size: Int): Double {
        if (x0 < 0 || y0 < 0 || x0 + size > f.w || y0 + size > f.h) return 0.0
        val cell = size / 8f
        val v = IntArray(64)
        for (r in 0..7) for (c in 0..7) {
            // берём точку у угла клетки, чтобы не попасть на фигуру
            val px = (x0 + c * cell + cell * 0.2f).toInt()
            val py = (y0 + r * cell + cell * 0.2f).toInt()
            v[r * 8 + c] = f.lum[py * f.w + px]
        }
        var good = 0
        var total = 0
        for (r in 0..7) for (c in 0..7) {
            val a = v[r * 8 + c]
            if (c < 7) { total++; if (abs(a - v[r * 8 + c + 1]) >= DIFF_MIN) good++ }
            if (r < 7) { total++; if (abs(a - v[(r + 1) * 8 + c]) >= DIFF_MIN) good++ }
            if (c < 6) { total++; if (abs(a - v[r * 8 + c + 2]) <= SAME_MAX) good++ }
            if (r < 6) { total++; if (abs(a - v[(r + 2) * 8 + c]) <= SAME_MAX) good++ }
        }
        return good.toDouble() / total
    }


    private fun edge(f: Frame, x0: Int, y0: Int, size: Int): Int {
        if (x0 < 1 || y0 < 1 || x0 + size + 1 > f.w || y0 + size + 1 > f.h) return -1
        val cell = size / 8f
        var tot = 0
        for (k in 1..7) for (r in 0..7) {
            val x = Math.round(x0 + k * cell)
            val y = (y0 + (r + 0.5f) * cell).toInt()
            tot += abs(f.lum[y * f.w + x - 1] - f.lum[y * f.w + x + 1])
            val x2 = (x0 + (r + 0.5f) * cell).toInt()
            val y2 = Math.round(y0 + k * cell)
            tot += abs(f.lum[(y2 - 1) * f.w + x2] - f.lum[(y2 + 1) * f.w + x2])
        }
        return tot
    }

    /** Оценка (0..1), насколько в прямоугольнике (в координатах экрана) всё ещё доска. */
    fun scoreRect(f: Frame, r: Rect): Double {
        val x = (r.left * f.scale).toInt()
        val y = (r.top * f.scale).toInt()
        val s = (r.width() * f.scale).toInt()
        return score(f, x, y, s)
    }

    /** Возвращает прямоугольник доски в координатах экрана или null. */
    fun find(f: Frame): Rect? {
        var best = 0.0
        var bx = 0; var by = 0; var bs = 0
        var size = f.w
        while (size >= f.w / 3) {
            var y = 0
            while (y + size <= f.h) {
                var x = 0
                while (x + size <= f.w) {
                    val sc = score(f, x, y, size)
                    if (sc > best) { best = sc; bx = x; by = y; bs = size }
                    x += 5
                }
                y += 5
            }
            size -= 8
        }
        if (best < ACCEPT) return null
        // уточнение: выравниваем окно по внутренним линиям сетки (контраст по обе стороны линии)
        val cx = bx; val cy = by; val cs = bs
        var bestEdge = -1
        for (s in cs - 10..cs + 10) for (y in cy - 10..cy + 10) for (x in cx - 10..cx + 10) {
            if (score(f, x, y, s) < best - 0.03) continue
            val e = edge(f, x, y, s)
            if (e > bestEdge) { bestEdge = e; bx = x; by = y; bs = s }
        }
        if (bestEdge < 0) return null
        val k = 1f / f.scale
        return Rect((bx * k).toInt(), (by * k).toInt(), ((bx + bs) * k).toInt(), ((by + bs) * k).toInt())
    }
}
