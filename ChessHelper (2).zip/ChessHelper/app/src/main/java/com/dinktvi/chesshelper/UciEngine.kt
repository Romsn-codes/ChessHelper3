package com.dinktvi.chesshelper

import android.content.Context
import java.io.BufferedWriter
import java.io.File
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Запускает Stockfish как отдельный процесс и говорит с ним по протоколу UCI. */
class UciEngine(private val ctx: Context) {
    /** cp — оценка в сотых пешки с точки зрения ходящей стороны (мат = ±100000). */
    class Line(val move: String, val scoreText: String, val cp: Int)
    class Result(val best: String?, val lines: List<Line>)

    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private val queue = LinkedBlockingQueue<String>()
    private val tail = ArrayDeque<String>()      // последние строки вывода — для диагностики
    private val eof = "\u0000EOF"
    @Volatile private var dead = false

    /** elo = 0 — полная сила. null в ответе — всё хорошо, иначе понятный текст ошибки. */
    fun start(elo: Int): String? {
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return "Нет libstockfish.so в приложении (см. README)"
        // файл должен быть программой (ELF), а не архивом .tar/.zip
        val magic = ByteArray(4)
        try { f.inputStream().use { it.read(magic) } } catch (_: Exception) {}
        if (!(magic[0] == 0x7f.toByte() && magic[1] == 'E'.code.toByte() && magic[2] == 'L'.code.toByte() && magic[3] == 'F'.code.toByte()))
            return "libstockfish.so — не программа (похоже на архив или не тот файл). Распакуй .tar и положи сам файл Stockfish"
        try { f.setExecutable(true) } catch (_: Exception) {}
        return try {
            proc = ProcessBuilder(f.absolutePath).redirectErrorStream(true).start()
            writer = proc!!.outputStream.bufferedWriter()
            val rd = proc!!.inputStream.bufferedReader()
            Thread {
                try {
                    while (true) {
                        val l = rd.readLine() ?: break
                        synchronized(tail) { tail.addLast(l); if (tail.size > 5) tail.removeFirst() }
                        queue.put(l)
                    }
                } catch (_: Exception) {}
                dead = true
                queue.put(eof)
            }.apply { isDaemon = true; start() }

            send("uci")
            waitFor("uciok", 10000)?.let { return it }
            send("setoption name MultiPV value 5")
            send("setoption name Threads value 2")
            if (elo > 0) {
                send("setoption name UCI_LimitStrength value true")
                send("setoption name UCI_Elo value $elo")
            } else {
                send("setoption name UCI_LimitStrength value false")
            }
            send("isready")
            waitFor("readyok", 10000)?.let { return it }
            null
        } catch (e: Exception) {
            "Не удалось запустить Stockfish: ${e.message}"
        }
    }

    private fun send(s: String) {
        try { writer?.apply { write(s); newLine(); flush() } } catch (_: Exception) { dead = true }
    }

    private fun nextLine(timeoutMs: Long): String? {
        if (dead && queue.isEmpty()) return null
        val l = queue.poll(timeoutMs, TimeUnit.MILLISECONDS) ?: return null
        return if (l == eof) null else l
    }

    /** null — дождались; иначе описание проблемы. */
    private fun waitFor(token: String, timeoutMs: Long): String? {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val left = end - System.currentTimeMillis()
            if (left <= 0) return "Stockfish молчит: нет ответа ${timeoutMs / 1000} с. ${lastOutput()}"
            val l = nextLine(left)
            if (l == null) {
                if (dead) return "Stockfish завершился сразу после запуска. ${exitHint()} ${lastOutput()}"
                continue
            }
            if (l.startsWith(token)) return null
        }
    }

    private fun lastOutput(): String {
        val t = synchronized(tail) { tail.joinToString(" | ") }
        return if (t.isEmpty()) "" else "Вывод: $t"
    }

    private fun exitHint(): String {
        val code = try {
            if (proc?.waitFor(1, TimeUnit.SECONDS) == true) proc!!.exitValue() else null
        } catch (_: Exception) { null }
        return when (code) {
            null -> ""
            132 -> "Код 132: процессор не поддерживает эту сборку — нужна обычная «armv8», не «dotprod»."
            139 -> "Код 139: сбой программы (возможно, не та сборка Stockfish)."
            126, 127 -> "Код $code: файл нельзя запустить — проверь libstockfish.so."
            else -> "Код выхода: $code."
        }
    }

    private fun parseInfo(l: String): Pair<Int, Line>? {
        if (!l.startsWith("info") || " multipv " !in l || " pv " !in l) return null
        if (" lowerbound" in l || " upperbound" in l) return null
        val t = l.split(' ')
        val mi = t.indexOf("multipv")
        val idx = t.getOrNull(mi + 1)?.toIntOrNull() ?: return null
        val si = t.indexOf("score")
        if (si < 0 || si + 2 >= t.size) return null
        val v = t[si + 2].toIntOrNull() ?: return null
        val cp: Int
        val text: String
        if (t[si + 1] == "mate") {
            cp = if (v > 0) 100000 - v else -100000 - v
            text = "M$v"
        } else {
            cp = v
            text = String.format(Locale.US, "%+.2f", v / 100f)
        }
        val mv = t.getOrNull(t.indexOf("pv") + 1) ?: return null
        if (mv.length < 4) return null
        return Pair(idx, Line(mv, text, cp))
    }

    /** Лучший ход (с учётом выбранного уровня) и до нескольких вариантов. */
    fun analyse(fen: String, movetimeMs: Int): Result {
        send("position fen $fen")
        send("go movetime $movetimeMs")
        val best = HashMap<Int, Line>()
        var bestMove: String? = null
        val end = System.currentTimeMillis() + movetimeMs + 8000
        while (System.currentTimeMillis() < end) {
            val l = nextLine(1000) ?: if (dead) break else continue
            if (l.startsWith("bestmove")) {
                bestMove = l.split(' ').getOrNull(1)?.takeIf { it.length >= 4 }
                break
            }
            parseInfo(l)?.let { best[it.first] = it.second }
        }
        return Result(bestMove, best.toSortedMap().values.toList())
    }

    /** Оценка конкретного хода. null — ход невозможен. */
    fun checkMove(fen: String, move: String, movetimeMs: Int): Line? {
        send("position fen $fen")
        send("go searchmoves $move movetime $movetimeMs")
        var last: Line? = null
        var bestMove: String? = null
        val end = System.currentTimeMillis() + movetimeMs + 8000
        while (System.currentTimeMillis() < end) {
            val l = nextLine(1000) ?: if (dead) break else continue
            if (l.startsWith("bestmove")) {
                bestMove = l.split(' ').getOrNull(1)
                break
            }
            parseInfo(l)?.let { if (it.first == 1) last = it.second }
        }
        // при невозможном ходе Stockfish игнорирует searchmoves и вернёт другой ход
        return if (bestMove == move) last else null
    }

    fun stop() {
        try { send("quit") } catch (_: Exception) {}
        proc?.destroy()
        proc = null
    }
}
