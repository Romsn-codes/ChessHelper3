package com.dinktvi.chesshelper

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "♟ Шахматный помощник"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        root.addView(label("\nУровень Stockfish"))
        root.addView(spinner(AppSettings.LEVELS.map { it.first }, AppSettings.levelIndex(this)) { AppSettings.setLevelIndex(this, it) })
        root.addView(label("\nСтиль игры"))
        root.addView(spinner(AppSettings.STYLES, AppSettings.styleIndex(this)) { AppSettings.setStyleIndex(this, it) })
        root.addView(label("\nДебютная система"))
        root.addView(spinner(Openings.NAMES, AppSettings.systemIndex(this)) { AppSettings.setSystemIndex(this, it) })
        root.addView(TextView(this).apply {
            text = "\nИгрок — тот, кто снизу доски. Система подсказывается в начале партии звёздочкой ★, " +
                "если ход не слишком ослабляет позицию; за чёрных ходы системы зеркалятся.\n\n" +
                "Как пользоваться:\n" +
                "1. Выбери уровень, стиль и систему, нажми «Запуск», разреши показ поверх других приложений и запись экрана.\n" +
                "2. Появится плавающее окно (его можно перетащить за заголовок). Открой шахматное приложение, чтобы доска была видна целиком.\n" +
                "3. Когда партия началась и фигуры стоят на стартовых местах, нажми «Начать»: первый раз это же калибровка, и приложение запомнит твой набор фигур. До «Начать» экран не читается.\n" +
                "4. Стрелки появляются, когда твой ход: зелёная — лучший, жёлтая и синяя — запасные. «Пауза» останавливает чтение.\n" +
                "Чтобы сменить уровень, стиль или систему — «Стоп» и запусти заново.\n\n" +
                "Используй для разбора партий и игры с ботами. В живых рейтинговых партиях это чит."
            textSize = 15f
        })
        root.addView(Button(this).apply {
            text = "Запуск"
            setOnClickListener { begin() }
        })
        root.addView(Button(this).apply {
            text = "Стоп"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }


    private fun label(t: String) = TextView(this).apply { text = t; textSize = 16f }

    private fun spinner(items: List<String>, selected: Int, onPick: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = onPick(position)
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши «Поверх других приложений» и вернись", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
