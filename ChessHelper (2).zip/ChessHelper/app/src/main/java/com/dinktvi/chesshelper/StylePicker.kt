package com.dinktvi.chesshelper

import kotlin.math.abs
import kotlin.math.max

/**
 * Стиль игры. Stockfish сам стиля не имеет, поэтому из его лучших вариантов
 * (не хуже лучшего более чем на tol сотых пешки) выбирается тот, что больше подходит стилю.
 */
object StylePicker {
    const val MIXED = 0
    const val AGGRESSIVE = 1
    const val DEFENSIVE = 2

    fun pick(lines: List<UciEngine.Line>, board: Array<CharArray>, white: Boolean, style: Int, tol: Int): String? {
        if (lines.isEmpty() || style == MIXED) return null
        val top = lines.maxOf { it.cp }
        val own = if (white) 'K' else 'k'
        val enemy = if (white) 'k' else 'K'
        var ok = -1; var occ = -1; var ek = -1; var eck = -1
        for (r in 0..7) for (c in 0..7) {
            if (board[r][c] == own) { ok = r; occ = c }
            if (board[r][c] == enemy) { ek = r; eck = c }
        }
        var bestMove: String? = null
        var bestScore = Int.MIN_VALUE
        for (l in lines) {
            if (l.cp < top - tol) continue
            val sc = l.cp + bonus(l.move, board, white, style, ok, occ, ek, eck)
            if (sc > bestScore) { bestScore = sc; bestMove = l.move }
        }
        return bestMove
    }

    private fun bonus(mv: String, b: Array<CharArray>, white: Boolean, style: Int,
                      ok: Int, oc: Int, ek: Int, ec: Int): Int {
        val (fr, fc) = Fen.squareToRC(mv.substring(0, 2))
        val (tr, tc) = Fen.squareToRC(mv.substring(2, 4))
        val piece = b[fr][fc].uppercaseChar()
        val capture = b[tr][tc] != ' '
        val advance = if (white) fr - tr else tr - fr          // >0 — вперёд, к сопернику
        val castling = piece == 'K' && abs(fc - tc) == 2
        var s = 0
        if (style == AGGRESSIVE) {
            if (capture) s += 40
            if (piece != 'K') s += (10 * advance).coerceIn(-20, 30)
            if (piece != 'K' && piece != 'P' && ek >= 0 && max(abs(tr - ek), abs(tc - ec)) <= 3) s += 25
            if (piece == 'K' && !castling) s -= 20
        } else if (style == DEFENSIVE) {
            if (castling) s += 35
            if (advance < 0) s += (15 * -advance).coerceAtMost(30)
            if (capture) s += 10
            if (piece == 'P' && ok >= 0 && abs(tc - oc) <= 1 && advance > 0) s -= 15
            if (piece != 'K' && piece != 'P' && ok >= 0 && max(abs(tr - ok), abs(tc - oc)) <= 2) s += 15
            if (piece != 'K' && piece != 'P' && advance >= 2) s -= 10
        }
        return s
    }
}
