package com.dinktvi.chesshelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_CALIBRATE = "calibrate"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "chess"
        private const val NOTIF_ID = 1
        private const val INTERVAL_MS = 1500L     // как часто смотрим на экран
        private const val THINK_MS = 800          // сколько думает Stockfish
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: ArrowOverlay? = null
    private lateinit var wm: WindowManager

    private var engine: UciEngine? = null
    private lateinit var recognizer: PieceRecognizer

    private var running = false
    private var boardRect: Rect? = null
    private var lastFen: String? = null
    @Volatile private var calibrateRequested = false
    private var lastStatus = ""
    private var panel: FloatingPanel? = null
    @Volatile private var active = false     // читаем экран только после «Начать»

    // игрок — тот, кто снизу доски
    private var stableGrid: Array<CharArray>? = null
    private var pendingGrid: Array<CharArray>? = null
    private var myTurn = true
    private var system: Openings.OpeningSystem = Openings.ALL[0]
    private var style = StylePicker.MIXED
    private var elo = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> if (!running) start(intent) 
            ACTION_CALIBRATE -> if (running) main.post { requestCalibrate() }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------- запуск ----------

    private fun start(intent: Intent) {
        createChannel()
        val n = buildNotification("Запускаюсь…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        recognizer = PieceRecognizer(getSharedPreferences("pieces", MODE_PRIVATE))
        system = Openings.byIndex(AppSettings.systemIndex(this))
        style = AppSettings.styleIndex(this)
        elo = AppSettings.LEVELS[AppSettings.levelIndex(this)].second

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)

        val size = realSize()
        reader = ImageReader.newInstance(size.first, size.second, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "chess-capture", size.first, size.second, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        addOverlay(size.first, size.second)
        panel = FloatingPanel(this, wm, { toggleActive() }, { requestCalibrate() }, { stopSelf() }).also { it.show() }

        thread = HandlerThread("chess-worker").also { it.start() }
        worker = Handler(thread!!.looper)
        running = true
        worker!!.post {
            val e = UciEngine(this)
            val err = e.start(elo)
            if (err != null) { status(err); return@post }
            engine = e
            status("Открой партию и нажми «Начать» в плавающем окне")
            tick()
        }
    }

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    private fun addOverlay(w: Int, h: Int) {
        val v = ArrowOverlay(this)
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0; lp.y = 0
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(v, lp)
        overlay = v
    }

    // ---------- главный цикл ----------

    private fun tick() {
        if (!running) return
        try {
            if (!active) {
                reader?.acquireLatestImage()?.close()      // пока не нажато «Начать» — экран не читаем
            } else {
                val ov = overlay
                val pn = panel
                // стрелки и плавающее окно попали бы в кадр и сбили бы распознавание — прячем на миг
                onMainSync { ov?.visibility = View.INVISIBLE; pn?.setVisible(false) }
                Thread.sleep(220)
                val bmp = grab()
                main.post { ov?.visibility = View.VISIBLE; pn?.setVisible(true) }
                if (bmp != null) { process(bmp); bmp.recycle() }
            }
        } catch (t: Throwable) {
            status("Ошибка: ${t.message}")
        }
        worker?.postDelayed({ tick() }, if (active) INTERVAL_MS else 400L)
    }

    // ---------- кнопки плавающего окна ----------

    private fun toggleActive() {
        if (active) {
            active = false
            panel?.setActive(false)
            clearArrows()
            status("Пауза. Нажми «Начать», когда продолжишь")
        } else {
            active = true
            lastFen = null; stableGrid = null; pendingGrid = null; myTurn = true
            if (!recognizer.calibrated) calibrateRequested = true   // первое «Начать» = калибровка по стартовой позиции
            panel?.setActive(true)
            status(if (calibrateRequested) "Калибровка: смотрю на стартовую позицию…" else "Слежу за доской…")
        }
    }

    private fun requestCalibrate() {
        calibrateRequested = true
        if (!active) { active = true; panel?.setActive(true) }
        status("Калибровка: смотрю на стартовую позицию…")
    }

    private fun process(bmp: Bitmap) {
        val frame = Frame(bmp)
        var rect = boardRect
        if (rect == null || BoardDetector.scoreRect(frame, rect) < 0.8) {
            rect = BoardDetector.find(frame)
            boardRect = rect
            lastFen = null
        }
        if (rect == null) {
            status("Доска не найдена на экране")
            clearArrows()
            return
        }
        if (calibrateRequested) {
            calibrateRequested = false
            val err = recognizer.calibrate(bmp, rect)
            if (err != null) status(err) else {
                lastFen = null; stableGrid = null; pendingGrid = null; myTurn = true
                status("Калибровка готова. Игрок — тот, кто снизу (${if (recognizer.whiteBottom) "белые" else "чёрные"})")
            }
            return
        }
        if (!recognizer.calibrated) {
            status("Нажми «Калибровка» в уведомлении (на стартовой позиции)")
            return
        }
        val grid = recognizer.read(bmp, rect)
        if (grid == null || !Fen.valid(grid)) {
            status("Позицию не распознал (нужна калибровка?)")
            return
        }

        // позиция принимается, только если она одинакова в двух кадрах подряд (защита от сбоев распознавания)
        val stable = stableGrid
        if (stable == null || !sameGrid(stable, grid)) {
            val pend = pendingGrid
            if (pend == null || !sameGrid(pend, grid)) { pendingGrid = grid; return }
            if (stable != null) updateTurn(stable, grid)
            stableGrid = grid
            pendingGrid = null
            lastFen = null
        }

        val me = if (recognizer.whiteBottom) 'w' else 'b'
        if (!myTurn) {
            status("Ход соперника…")
            clearArrows()
            return
        }
        val fen = Fen.build(grid, me)
        if (fen == lastFen) return
        lastFen = fen

        val eng = engine ?: return
        val res = eng.analyse(fen, THINK_MS)
        if (res.best == null) { clearArrows(); return }

        // ход выбранной дебютной системы — если он возможен и не слишком ослабляет позицию
        var bookMove: UciEngine.Line? = null
        if (system.steps.isNotEmpty() && Openings.pieceCount(grid) >= Openings.MIN_PIECES_FOR_BOOK) {
            val top = res.lines.firstOrNull()?.cp ?: 0
            for (cand in Openings.candidates(system, grid, me == 'w')) {
                val l = eng.checkMove(fen, cand, 250) ?: continue
                if (l.cp >= top - Openings.TOLERANCE_CP) { bookMove = l; break }
            }
        }

        // стиль: из хороших вариантов берём подходящий агрессивной/защитной игре (на низких уровнях допуск шире)
        val tol = if (elo == 0) 50 else (50 + (2800 - elo) / 20).coerceIn(50, 130)
        val mainMove = StylePicker.pick(res.lines, grid, me == 'w', style, tol) ?: res.best

        val moves = ArrayList<Pair<String, String>>()   // ход -> подпись
        if (bookMove != null) moves.add(Pair(bookMove.move, "★ " + bookMove.scoreText))
        val bestLine = res.lines.firstOrNull { it.move == mainMove }
        moves.add(Pair(mainMove, bestLine?.scoreText ?: ""))
        for (l in res.lines) if (moves.none { it.first == l.move }) moves.add(Pair(l.move, l.scoreText))
        val shown = moves.distinctBy { it.first }.take(3)

        val whiteBottom = recognizer.whiteBottom
        val arrows = shown.map { (mv, label) ->
            val (fr, fc) = Fen.squareToRC(mv.substring(0, 2))
            val (tr, tc) = Fen.squareToRC(mv.substring(2, 4))
            fun sr(r: Int) = if (whiteBottom) r else 7 - r
            fun sc(c: Int) = if (whiteBottom) c else 7 - c
            ArrowOverlay.Arrow(sr(fr), sc(fc), sr(tr), sc(tc), label)
        }
        val rf = RectF(rect)
        main.post { overlay?.setArrows(rf, arrows) }
        val first = shown[0]
        status("Твой ход: ${first.first}" + (if (bookMove != null) " (система: ${system.name})" else "") +
            if (first.second.isNotEmpty()) " ${first.second}" else "")
    }

    private fun clearArrows() { main.post { overlay?.setArrows(null, emptyList()) } }

    private fun sameGrid(a: Array<CharArray>, b: Array<CharArray>): Boolean {
        for (r in 0..7) for (c in 0..7) if (a[r][c] != b[r][c]) return false
        return true
    }

    /** По клеткам, куда «пришли» фигуры, понимаем, кто сходил последним. */
    private fun updateTurn(old: Array<CharArray>, new: Array<CharArray>) {
        var whiteArrived = false
        var blackArrived = false
        for (r in 0..7) for (c in 0..7) {
            val n = new[r][c]
            if (n != ' ' && n != old[r][c]) { if (n.isUpperCase()) whiteArrived = true else blackArrived = true }
        }
        val meWhite = recognizer.whiteBottom
        myTurn = when {
            whiteArrived && !blackArrived -> !meWhite      // сходили белые -> моя очередь, если я чёрные
            blackArrived && !whiteArrived -> meWhite
            else -> true                                    // оба цвета (быстрый ответ) или неясно — считаем, что моя очередь
        }
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * img.width
            val full = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            if (rowPad == 0) return full
            val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            full.recycle()
            return cropped
        } finally {
            img.close()
        }
    }

    private fun onMainSync(block: () -> Unit) {
        val latch = CountDownLatch(1)
        main.post { block(); latch.countDown() }
        latch.await(500, TimeUnit.MILLISECONDS)
    }

    // ---------- уведомление ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Шахматный помощник", NotificationManager.IMPORTANCE_LOW))
    }

    private fun action(act: String, title: String, req: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this, req, Intent(this, CaptureService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(null, title, pi).build()
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Шахматный помощник")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .addAction(action(ACTION_CALIBRATE, "Калибровка", 1))
            .addAction(action(ACTION_STOP, "Стоп", 2))
            .build()

    private fun status(text: String) {
        if (text == lastStatus) return
        lastStatus = text
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        main.post { panel?.setStatus(text) }
    }

    // ---------- остановка ----------

    override fun onDestroy() {
        running = false
        worker?.removeCallbacksAndMessages(null)
        panel?.remove()
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        engine?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
