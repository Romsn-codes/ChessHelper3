package com.dinktvi.chesshelper

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Распознаёт фигуры по силуэтам. Шаблоны берутся с самой доски в стартовой позиции
 * (калибровка), поэтому работает с любым набором фигур и любой темой доски.
 */
class PieceRecognizer(private val prefs: SharedPreferences) {
    private val n = 32            // клетка масштабируется до 32x32
    private val inner = 28        // рабочая область 28x28 (без рамки по 2 px)
    private val m = 14            // силуэт 14x14
    private val types = "PNBRQK"

    private var templates: Array<FloatArray>? = null
    private var whiteLum = 200f
    private var blackLum = 50f
    var whiteBottom = true
        private set

    val calibrated: Boolean get() = templates != null

    init { load() }

    private class Cell(val sil: FloatArray, val fill: Float, val lum: Float)

    private fun analyze(board: Bitmap, rect: Rect, r: Int, c: Int): Cell {
        val cw = rect.width() / 8f
        val ch = rect.height() / 8f
        val w = cw.roundToInt().coerceAtLeast(8)
        val h = ch.roundToInt().coerceAtLeast(8)
        val x = (rect.left + c * cw).roundToInt().coerceIn(0, board.width - w)
        val y = (rect.top + r * ch).roundToInt().coerceIn(0, board.height - h)
        val crop = Bitmap.createBitmap(board, x, y, w, h)
        val s = Bitmap.createScaledBitmap(crop, n, n, true)
        val px = IntArray(n * n)
        s.getPixels(px, 0, n, 0, 0, n, n)
        if (s !== crop) s.recycle()
        crop.recycle()

        // фон клетки = медиана цвета по четырём углам (переживает подсветку последнего хода)
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        for (cy in intArrayOf(0, n - 4)) for (cx in intArrayOf(0, n - 4))
            for (yy in cy until cy + 4) for (xx in cx until cx + 4) {
                val p = px[yy * n + xx]
                rs.add((p shr 16) and 255); gs.add((p shr 8) and 255); bs.add(p and 255)
            }
        rs.sort(); gs.sort(); bs.sort()
        val br = rs[rs.size / 2]; val bg = gs[gs.size / 2]; val bb = bs[bs.size / 2]

        val mask = FloatArray(inner * inner)
        var sum = 0f
        var lumSum = 0f
        var lumCnt = 0
        val off = (n - inner) / 2
        for (yy in 0 until inner) for (xx in 0 until inner) {
            val p = px[(yy + off) * n + (xx + off)]
            val pr = (p shr 16) and 255; val pg = (p shr 8) and 255; val pb = p and 255
            val d = abs(pr - br) + abs(pg - bg) + abs(pb - bb)
            val v = ((d - 40) / 80f).coerceIn(0f, 1f)
            mask[yy * inner + xx] = v
            sum += v
            if (v > 0.5f && yy in 7..20 && xx in 7..20) {
                lumSum += (pr * 299 + pg * 587 + pb * 114) / 1000f
                lumCnt++
            }
        }
        val sil = FloatArray(m * m)
        val k = inner / m
        for (yy in 0 until m) for (xx in 0 until m) {
            var a = 0f
            for (dy in 0 until k) for (dx in 0 until k) a += mask[(yy * k + dy) * inner + xx * k + dx]
            sil[yy * m + xx] = a / (k * k)
        }
        return Cell(sil, sum / (inner * inner), if (lumCnt > 0) lumSum / lumCnt else 0f)
    }

    /** Калибровка по стартовой позиции. null — успех, иначе текст ошибки. */
    fun calibrate(board: Bitmap, rect: Rect): String? {
        val cells = Array(8) { r -> Array(8) { c -> analyze(board, rect, r, c) } }
        val empty = 0.06f
        var midEmpty = 0; var edgeFull = 0
        for (r in 0..7) for (c in 0..7) {
            val e = cells[r][c].fill < empty
            if (r in 2..5 && e) midEmpty++
            if (r !in 2..5 && !e) edgeFull++
        }
        if (midEmpty < 30 || edgeFull < 30) return "Это не стартовая позиция — калибровка отменена"

        fun avgLum(rows: IntRange): Float {
            var s = 0f; var k = 0
            for (r in rows) for (c in 0..7) { s += cells[r][c].lum; k++ }
            return s / k
        }
        val top = avgLum(0..1)
        val bottom = avgLum(6..7)
        if (abs(top - bottom) < 30f) return "Не отличаю белые фигуры от чёрных — калибровка отменена"
        val wb = bottom > top

        val sums = Array(6) { FloatArray(m * m) }
        val counts = IntArray(6)
        var wl = 0f; var wc = 0; var bl = 0f; var bc = 0
        for (r in 0..7) for (c in 0..7) {
            if (r in 2..5) continue
            val br = if (wb) r else 7 - r
            val bcI = if (wb) c else 7 - c
            val type = if (br == 1 || br == 6) 'P' else "RNBQKBNR"[bcI]
            val ti = types.indexOf(type)
            val cell = cells[r][c]
            for (i in sums[ti].indices) sums[ti][i] += cell.sil[i]
            counts[ti]++
            if (br >= 6) { wl += cell.lum; wc++ } else { bl += cell.lum; bc++ }
        }
        templates = Array(6) { t -> FloatArray(m * m) { sums[t][it] / counts[t] } }
        whiteLum = wl / wc
        blackLum = bl / bc
        whiteBottom = wb
        save()
        return null
    }

    /** Возвращает доску в координатах a8=[0][0] либо null. */
    fun read(board: Bitmap, rect: Rect): Array<CharArray>? {
        val tpl = templates ?: return null
        val out = Array(8) { CharArray(8) { ' ' } }
        for (r in 0..7) for (c in 0..7) {
            val cell = analyze(board, rect, r, c)
            if (cell.fill < 0.06f) continue
            var bestT = 0; var bestD = Float.MAX_VALUE
            for (t in 0 until 6) {
                var d = 0f
                val a = tpl[t]
                for (i in a.indices) { val e = a[i] - cell.sil[i]; d += e * e }
                if (d < bestD) { bestD = d; bestT = t }
            }
            val white = abs(cell.lum - whiteLum) < abs(cell.lum - blackLum)
            val ch = types[bestT]
            val br = if (whiteBottom) r else 7 - r
            val bc = if (whiteBottom) c else 7 - c
            out[br][bc] = if (white) ch else ch.lowercaseChar()
        }
        return out
    }

    private fun save() {
        val t = templates ?: return
        prefs.edit()
            .putString("tpl", t.joinToString(";") { it.joinToString(",") })
            .putFloat("wl", whiteLum).putFloat("bl", blackLum)
            .putBoolean("wb", whiteBottom).apply()
    }

    private fun load() {
        val s = prefs.getString("tpl", null) ?: return
        try {
            val t = s.split(";").map { row -> row.split(",").map { it.toFloat() }.toFloatArray() }
            if (t.size == 6 && t.all { it.size == m * m }) {
                templates = t.toTypedArray()
                whiteLum = prefs.getFloat("wl", 200f)
                blackLum = prefs.getFloat("bl", 50f)
                whiteBottom = prefs.getBoolean("wb", true)
            }
        } catch (_: Exception) {}
    }
}
